import { BrowserRouter } from "react-router-dom"
import { AppRouter } from "./components/AppRouter/AppRouter"
import { ToastContainer } from "react-toastify"
import { GlobalStyles, StyledEngineProvider } from "@mui/material"
import { ErrorBoundary } from "./components/ErrorBoundary/ErrorBoundary"

function App() {

  return (
    <StyledEngineProvider enableCssLayer>

      <GlobalStyles styles="@layer theme, base, mui, components, utilities;"></GlobalStyles>
      <ErrorBoundary>
        <BrowserRouter>
          <AppRouter />
          <ToastContainer />
        </BrowserRouter>
      </ErrorBoundary>
    </StyledEngineProvider>
  )
}

export default App
