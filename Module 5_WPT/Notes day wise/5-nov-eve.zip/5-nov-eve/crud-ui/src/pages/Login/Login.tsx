import { Box, Button, TextField, Typography } from "@mui/material";
import LockIcon from '@mui/icons-material/Lock';
import { Controller, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { loginValidationSchema } from "./ValidationSchema";
import { showErrorToast } from "../../utils/ToastUtil";
import { apiClient } from "../../api-client/ApiClient";
import { getToken, storeToken } from "../../utils/TokenUtil";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";

export function Login() {

    const navigate = useNavigate();

    const {
        formState: { errors },
        handleSubmit,
        control
    } = useForm({
        resolver: yupResolver(loginValidationSchema)
    });

    useEffect(()=>{
        const token = getToken();
        if(token){
            navigate("/");
        }
    },[])

    const onSubmit = async (formData) => {
        console.log(formData);
        try {
            const response = await apiClient.post("/admin/login", formData);
            console.log(response.data);
            storeToken(response.data.token);
            navigate("/");
            // localStorage.getItem();
            // localStorage.removeItem();
        } catch (error) {
            console.log(error.response);
            if (error.response.status === 400) {
                showErrorToast("Phone or Password is invalid");
            }
            else {
                showErrorToast("Failed to login");
            }

        }
    }

    return (
        <Box className="min-h-screen bg-gray-100 flex items-center justify-center">
            <Box className="w-full max-w-md bg-white p-8 rounded-xl shadow-lg">
                <Box className="mx-auto w-14 h-14 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center">
                    <LockIcon />
                </Box>
                <Typography className="mt-4 text-2xl font-bold text-center text-gray-800">
                    Login to continue with CRUD UI
                </Typography>
                <Box component="form" onSubmit={handleSubmit(onSubmit)} noValidate className="mt-8 flex flex-col gap-6">
                    <Controller
                        name="phone"
                        control={control}
                        render={({ field }) => {
                            return (
                                <TextField
                                    {...field}
                                    label="Phone"
                                    variant="outlined"
                                    fullWidth
                                    error={!!errors.phone}
                                    helperText={errors.phone?.message}
                                />
                            )
                        }}
                    />
                    <Controller
                        name="password"
                        control={control}
                        render={({ field }) => {
                            return (
                                <TextField
                                    {...field}
                                    type="password"
                                    label="Password"
                                    variant="outlined"
                                    fullWidth
                                    error={!!errors.password}
                                    helperText={errors.password?.message}
                                />
                            )
                        }}
                    />

                    <Button variant="contained" type="submit" fullWidth className="bg-indigo-600 rounded-lg text-white">Login</Button>
                </Box>
            </Box>
        </Box>
    )
}