import {object, string} from 'yup';

export const loginValidationSchema = object({
    phone: string().required("Phone no. is required"),
    password: string().required("Password is required")
});