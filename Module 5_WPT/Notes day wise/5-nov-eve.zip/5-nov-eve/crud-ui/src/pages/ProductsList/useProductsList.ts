import { useCallback, useEffect, useState } from "react";
import type { IProduct } from "./types";
import { apiClient } from "../../api-client/ApiClient";
import { showErrorToast } from "../../utils/ToastUtil";
import { getToken } from "../../utils/TokenUtil";

export function useProductsList() {

    const [products, setProducts] = useState<IProduct[]>([]);
    const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
    const [selectedProductId, setSelectedProductId] = useState(0);

    const fetchProductsData = useCallback(async () => {
        try {
            const token = getToken();
            const response = await apiClient.get("/product", { headers: { 'Authorization': `Bearer ${token}` } });
            const productsData = response.data;
            setProducts(productsData);
        } catch (error) {
            console.log(error);
        }

    }, []);

    useEffect(() => {
        fetchProductsData();
    }, []);

    const deleteProduct = async () => {
        try {
            const token = getToken();
            const response = await apiClient.delete(`/product/${selectedProductId}`, { headers: { 'Authorization': `Bearer ${token}` } });
            console.log(response.data);
            setOpenDeleteDialog(false);
            fetchProductsData();
        } catch (error) {
            console.log(error);
            showErrorToast("Deletion Failed !");
        }
    }

    return {
        products,
        openDeleteDialog,
        setOpenDeleteDialog,
        selectedProductId,
        setSelectedProductId,
        deleteProduct
    }

}