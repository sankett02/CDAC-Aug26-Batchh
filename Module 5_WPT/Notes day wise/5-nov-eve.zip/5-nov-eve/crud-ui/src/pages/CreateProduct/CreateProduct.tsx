import { Box, Button, Grid, TextField, Typography } from "@mui/material";
import { memo } from "react";
import type { IFormData } from "./types";
import { apiClient } from "../../api-client/ApiClient";
import { showErrorToast, showSuccessToast } from "../../utils/ToastUtil";
import AddCircleIcon from '@mui/icons-material/AddCircle';
import { Controller, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { productValidationSchema } from "./ValidationSchema";
import { getToken } from "../../utils/TokenUtil";

export const CreateProduct = memo(() => {


    // const [formData, setFormData] = useState<IFormData>({ name: "", description: "", price: "", qty: "" });

    // const handleChange = (event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement, Element>) => {
    //     setFormData({ ...formData, [event.target.name]: event.target.value });
    // }

    const {
        control, // connect each filed to the form 
        reset,
        formState: { errors },
        handleSubmit
    } = useForm<IFormData>({
        resolver: yupResolver(productValidationSchema)
    });

    /*
        errors = {
            description : {message: ""},
            name: {message: ""}
        }
    */
    const onSubmit = async (formData: IFormData) => {

        console.log(formData);
        try {
            const token = getToken();
            const response = await apiClient.post("/product", formData, {headers:{'Authorization':`Bearer ${token}`}});
            console.log(response);
            console.log(response.data);
            showSuccessToast("Product Created !");
            reset();
        } catch (error) {
            console.log(error);
            showErrorToast("Product Creation Failed !");
        }
    }

    return (
        <Box>
            <Box className="p-6 bg-white rounded-xl shadow-md border-l-4 border-indigo-600 flex items-center gap-4">
                <Box className="w-12 h-12 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center">
                    <AddCircleIcon />
                </Box>
                <Box>
                    <Typography className="text-2xl font-bold text-gray-800">Add a new product</Typography>
                    <Typography className="text-sm text-gray-500">Fill the correct values in the form below</Typography>
                </Box>
            </Box>
            
            <Box
                component="form"
                className="bg-white p-6 shadow-lg rounded-xl"
                onSubmit={handleSubmit(onSubmit)}
                noValidate
                sx={{ marginTop: '30px' }}>
                <Grid container rowSpacing={4} columnSpacing={5} sx={{ mb: 4 }}>
                    <Grid size={4}>
                        <Controller
                            name="name"
                            control={control}
                            render={(controller) => {
                                const { field } = controller;
                                return (
                                    <TextField
                                        {...field}
                                        label="Name"
                                        variant="outlined"
                                        fullWidth
                                        // error={errors.name ? true : false}
                                        error={!!errors.name}
                                        helperText={errors.name?.message}
                                    />
                                )
                            }}
                        ></Controller>

                    </Grid>
                    <Grid size={4}>
                        <Controller
                            name="description"
                            control={control}
                            render={(controller) => {
                                const { field } = controller;
                                return (
                                    <TextField
                                        {...field}
                                        label="Description"
                                        variant="outlined"
                                        fullWidth
                                        error={!!errors.description}
                                        helperText={errors.description?.message}
                                    />
                                )
                            }}
                        />

                    </Grid>
                </Grid>
                <Grid container rowSpacing={4} columnSpacing={5} sx={{ mb: 4 }}>
                    <Grid size={4}>
                        <Controller
                            name="price"
                            control={control}
                            render={({ field }) => (
                                <TextField
                                    {...field}
                                    label="Price"
                                    variant="outlined"
                                    fullWidth
                                    error={!!errors.price}
                                    helperText={errors.price?.message}

                                />
                            )
                            }
                        />

                    </Grid>
                    <Grid size={4}>
                        <Controller
                            name="qty"
                            control={control}
                            render={({ field }) => (
                                <TextField
                                    {...field}
                                    label="Quantity"
                                    variant="outlined"
                                    fullWidth
                                    error={!!errors.qty}
                                    helperText={errors.qty?.message}

                                />
                            )
                            }
                        />
                    </Grid>
                </Grid>
                <Button type="submit" variant="contained" className="bg-indigo-600 text-white">Add Product</Button>

            </Box>
        </Box>
    )
}) 