import { number, object, string } from 'yup';

export const productValidationSchema = object({
    name: string()
        .required("Name is required")
        .min(3, "Minimum 3 characters are required"),

    description: string().
        required("Description is required")
        .max(100, "Maximum 100 characters allowed"),

    price: number()
        .typeError("Only numeric value is allowed")
        .required("Price is required")
        .positive("Price cannot be -ve or 0"),

    qty: number()
        .required("Quantity is required")
        .integer("Quantity must be integer")
        .min(1, "Quantity must be atleast 1")
});