export function storeToken(token:string){
    localStorage.setItem("admin-token", token);
}

export function getToken(){
    return localStorage.getItem("admin-token");
}

export function removeToken(){
    localStorage.removeItem("admin-token");
}