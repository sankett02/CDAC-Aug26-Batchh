import { Box, Button, Typography } from "@mui/material";
import { Component, type ErrorInfo } from "react";
import ErrorIcon from '@mui/icons-material/Error';

export class ErrorBoundary extends Component {

    constructor() {
        super();
        this.state = {
            error: null
        }
    }

    componentDidCatch(error: Error, errorInfo: ErrorInfo): void {
        this.setState({ error: error });
    }

    handleReload = ()=>{
        window.location.reload();
    }

    handleVisitDashboard = ()=> {
        window.location.href = "/";
    }

    render() {
        if (this.state.error) {
            return (
                <Box className="min-h-screen bg-gray-100 flex items-center justify-center">
                    <Box className="w-full max-w-md bg-white p-8 rounded-xl shadow-lg">
                        <Box className="mx-auto w-16 h-16 rounded-full bg-red-100 text-red-600 flex items-center justify-center">
                            <ErrorIcon />
                        </Box>
                        <Typography className="mt-4 text-2xl font-bold text-center text-gray-800">
                            Something Went Wrong !
                        </Typography>
                        <Typography className="mt-2 text-center text-sm text-gray-500">
                            Please try again later, or reload the screen
                        </Typography>
                        <Box className="p-6 text-center">
                            <Button variant="contained" className="bg-indigo-600 text-white rounded-xl mr-4" onClick={this.handleReload}>
                                Reload
                            </Button>
                            <Button variant="contained" className="bg-indigo-600 text-white rounded-xl mr-4" onClick={this.handleVisitDashboard}>
                                Go To Dashboard
                            </Button>
                        </Box>

                    </Box>
                </Box>
            )
        }
        else {
            return this.props.children
        }
    }

}