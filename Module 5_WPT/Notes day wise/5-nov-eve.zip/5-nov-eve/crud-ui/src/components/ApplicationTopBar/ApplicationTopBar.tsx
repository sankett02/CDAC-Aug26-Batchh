import { AppBar, Box, Button, IconButton, Toolbar, Typography } from "@mui/material";
import MenuIcon from '@mui/icons-material/Menu';
import type { IApplicationTopBar } from "./types";
import { memo } from "react";
import { removeToken } from "../../utils/TokenUtil";
import { useNavigate } from "react-router-dom";

export const ApplicationTopBar = memo((props: IApplicationTopBar) => {

    const { menuIconClickHandler } = props;

    const navigate = useNavigate();

    const handleLogout = ()=>{
        removeToken();
        navigate("/login");
    }

    return (
        <Box sx={{ flexGrow: 1 }} >
            <AppBar position="fixed" className="bg-indigo-600" sx={{ zIndex: (theme) => theme.zIndex.drawer + 1 }}>
                <Toolbar>
                    <IconButton
                        size="large"
                        edge="start"
                        color="inherit"
                        aria-label="menu"
                        sx={{ mr: 2 }}
                        onClick={menuIconClickHandler}
                    >
                        <MenuIcon />
                    </IconButton>
                    <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                        CRUD UI
                    </Typography>
                    <Button color="inherit" onClick={handleLogout}>Logout</Button>
                </Toolbar>
            </AppBar>
        </Box>
    )
}) 