import { Component } from "react";

export class ErrorBoundary extends Component{

    constructor(){
        super();
        this.state = {
            error: null
        }
    }

    componentDidCatch(error, errorInfo){
        this.setState({error: error});
    }

    render(){
        if(this.state.error){
            return (
                <h4>Something went wrong...!</h4>
            )
        }
        else{
            return this.props.children
            
        }
    }
}