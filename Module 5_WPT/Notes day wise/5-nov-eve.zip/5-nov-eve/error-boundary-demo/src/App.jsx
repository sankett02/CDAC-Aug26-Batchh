import { ErrorBoundary } from "./ErrorBoundary"
import { Footer } from "./Footer"
import { Navbar } from "./Navbar"
import { ScoreCard } from "./ScoreCard"


function App() {

  return (
    <>
      <Navbar />
      <ErrorBoundary>
        <ScoreCard />
      </ErrorBoundary>

      <Footer />
    </>
  )
}

export default App
