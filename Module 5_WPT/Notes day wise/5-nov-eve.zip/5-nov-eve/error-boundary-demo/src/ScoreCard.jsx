import { useState } from "react"

export function ScoreCard() {

    const [score, setScore] = useState(0);

    const handlePlus = ()=>{
        setScore(score+7);
    }

    if(score>=50){
        throw new Error("Invalid score value");
    }

    return (
        <div>
            <h2>Score: {score}</h2>
            <button onClick={handlePlus}>+</button>
        </div>
    )
}