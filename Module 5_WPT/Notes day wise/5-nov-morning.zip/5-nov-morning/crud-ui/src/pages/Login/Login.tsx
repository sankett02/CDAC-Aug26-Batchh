import { Box, Button, TextField, Typography } from "@mui/material";
import LockIcon from '@mui/icons-material/Lock';

export function Login() {
    return (
        <Box className="min-h-screen bg-gray-100 flex items-center justify-center">
            <Box className="w-full max-w-md bg-white p-8 rounded-xl shadow-lg">
                <Box className="w-14 h-14 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center">
                    <LockIcon />
                </Box>
                <Typography className="mt-4 text-2xl font-bold text-center text-gray-800">
                    Login to continue with CRUD UI
                </Typography>
                <Box component="form" noValidate className="mt-8 flex flex-col gap-6">
                    <TextField
                        // {...field}
                        label="Phone"
                        variant="outlined"
                        fullWidth
                        // error={!!errors.description}
                        // helperText={errors.description?.message}
                    />
                    <TextField
                        // {...field}
                        label="Password"
                        variant="outlined"
                        fullWidth
                        // error={!!errors.description}
                        // helperText={errors.description?.message}
                    />
                    <Button variant="contained" type="submit" fullWidth className="bg-indigo-600 rounded-lg text-white">Login</Button>
                </Box>
            </Box>
        </Box>
    )
}