import axios from "axios";

export const apiClient = axios.create({
    baseURL : "http://127.0.0.1:7500",
    timeout : 5000
})